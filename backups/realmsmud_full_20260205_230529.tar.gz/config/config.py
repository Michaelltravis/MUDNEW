"""
RealmsMUD Configuration
=======================
Game settings and constants.
"""

import os

class Config:
    """Game configuration settings."""
    
    # Server Settings
    PORT = 4000
    HOST = '0.0.0.0'
    MAX_PLAYERS = 100
    TICKS_PER_SECOND = 10
    
    # Paths
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    WORLD_DIR = os.path.join(BASE_DIR, 'world')
    PLAYER_DIR = os.path.join(BASE_DIR, 'lib', 'players')
    LOG_DIR = os.path.join(BASE_DIR, 'log')

    # Web map settings
    MAP_PORT = 4001
    MAP_HOST = '0.0.0.0'
    MAP_PUBLIC_HOST = '72.35.132.11'
    MAP_VIEW_SIZE = 11
    
    # Game Settings
    STARTING_ROOM = 3001  # Temple of Midgaard equivalent
    VOID_ROOM = 1  # Limbo
    MORTAL_START_ROOM = 3001
    IMMORTAL_START_ROOM = 1200
    
    # Level Settings
    MAX_MORTAL_LEVEL = 50
    MAX_IMMORTAL_LEVEL = 60
    IMMORTAL_LEVEL = 51

    # Email / password reset (SMTP)
    SMTP_HOST = None
    SMTP_PORT = 587
    SMTP_USER = None
    SMTP_PASS = None
    SMTP_FROM = None
    SMTP_TLS = True
    PASSWORD_RESET_TTL_HOURS = 24
    
    # Combat Settings
    PULSE_VIOLENCE = 2  # seconds between combat rounds
    PULSE_MOBILE = 10  # seconds between mob actions
    
    # Character Creation
    STARTING_GOLD = 100
    STARTING_EXPERIENCE = 0
    
    # Stat Limits
    MAX_STAT = 25
    MIN_STAT = 3
    
    # Experience multipliers by level
    EXP_MULTIPLIER = 1.4
    BASE_EXP = 800

    # Bonus XP settings
    EXPLORATION_XP_BASE = 40
    EXPLORATION_XP_PER_LEVEL = 5
    QUEST_XP_BONUS_PERCENT = 0.05  # 5% of next level XP
    BOSS_XP_BONUS_PERCENT = 0.50   # 50% bonus for boss kills
    STREAK_XP_BONUS_PER_KILL = 0.02  # 2% per streak stack
    STREAK_XP_BONUS_CAP = 0.30       # 30% cap

    # Rested XP settings
    RESTED_XP_RATE = 0.02  # 2% of next level XP per hour offline
    RESTED_XP_CAP = 0.50   # 50% of next level XP

    # Travel settings
    TRAVEL_COOLDOWN_SECONDS = 60
    
    # Regeneration rates (per tick)
    # Base regen rates (% of max per 60s tick) - multiplied by position
    # Standing=1x, Sitting=1.25x, Resting=1.5x, Sleeping=2x, Fighting=0.5x
    HP_REGEN_RATE = 0.12      # 12% base → 24% sleeping
    MANA_REGEN_RATE = 0.15    # 15% base → 30% sleeping  
    MOVE_REGEN_RATE = 0.20    # 20% base → 40% sleeping

    # Tick intervals (seconds)
    AFFECT_TICK_SECONDS = 6    # DOT/HOT effects tick rate
    POISON_TICK_SECONDS = 3    # Poison tick rate (faster feedback)
    
    # Colors (ANSI)
    COLORS = {
        'reset': '\033[0m',
        'bold': '\033[1m',
        'red': '\033[31m',
        'green': '\033[32m',
        'yellow': '\033[33m',
        'blue': '\033[34m',
        'magenta': '\033[35m',
        'cyan': '\033[36m',
        'white': '\033[37m',
        'bright_red': '\033[91m',
        'bright_green': '\033[92m',
        'bright_yellow': '\033[93m',
        'bright_blue': '\033[94m',
        'bright_magenta': '\033[95m',
        'bright_cyan': '\033[96m',
    }
    
    # Race definitions
    RACES = {
        'human': {
            'name': 'Human',
            'description': 'Versatile and adaptable, humans excel in all professions.',
            'stat_mods': {'str': 0, 'int': 0, 'wis': 0, 'dex': 0, 'con': 0, 'cha': 1},
            'size': 'medium',
            'abilities': ['quick_learner'],
        },
        'elf': {
            'name': 'Elf',
            'description': 'Graceful and wise, elves are masters of magic and archery.',
            'stat_mods': {'str': -1, 'int': 2, 'wis': 1, 'dex': 2, 'con': -2, 'cha': 1},
            'size': 'medium',
            'abilities': ['infravision', 'resist_charm'],
        },
        'dwarf': {
            'name': 'Dwarf',
            'description': 'Stout and hardy, dwarves are renowned warriors and craftsmen.',
            'stat_mods': {'str': 1, 'int': -1, 'wis': 1, 'dex': -1, 'con': 3, 'cha': -1},
            'size': 'small',
            'abilities': ['infravision', 'resist_poison', 'resist_magic'],
        },
        'halfling': {
            'name': 'Halfling',
            'description': 'Small and nimble, halflings are excellent thieves and scouts.',
            'stat_mods': {'str': -2, 'int': 0, 'wis': 0, 'dex': 3, 'con': 0, 'cha': 1},
            'size': 'small',
            'abilities': ['sneak_bonus', 'resist_fear'],
        },
        'half_orc': {
            'name': 'Half-Orc',
            'description': 'Strong and fierce, half-orcs are formidable warriors.',
            'stat_mods': {'str': 3, 'int': -2, 'wis': -1, 'dex': 0, 'con': 2, 'cha': -2},
            'size': 'medium',
            'abilities': ['infravision', 'berserk'],
        },
        'gnome': {
            'name': 'Gnome',
            'description': 'Clever and curious, gnomes have an affinity for illusion magic.',
            'stat_mods': {'str': -2, 'int': 2, 'wis': 0, 'dex': 1, 'con': 0, 'cha': 0},
            'size': 'small',
            'abilities': ['infravision', 'illusion_bonus'],
        },
        'dark_elf': {
            'name': 'Dark Elf',
            'description': 'Mysterious and deadly, dark elves wield shadow magic.',
            'stat_mods': {'str': 0, 'int': 2, 'wis': 0, 'dex': 2, 'con': -1, 'cha': -1},
            'size': 'medium',
            'abilities': ['infravision', 'faerie_fire', 'light_sensitivity'],
        },
    }
    
    # Class definitions
    CLASSES = {
        'warrior': {
            'name': 'Warrior',
            'description': 'Masters of combat, warriors excel in melee and defense.',
            'prime_stat': 'str',
            'hit_dice': 12,
            'mana_dice': 2,
            'move_dice': 6,
            'thac0_progression': 'fast',
            'save_progression': 'warrior',
            'skills': ['kick', 'bash', 'rescue', 'disarm', 'second_attack', 'third_attack', 'parry',
                      'shield_block', 'cleave', 'battleshout', 'intimidate'],
            'spells': [],
            # Warriors also gain rage abilities: execute (15), rampage (20), warcry (10), ignorepain (8)
            # And can switch stances: battle, berserk, defensive, precision
        },
        'mage': {
            'name': 'Mage',
            'description': 'Wielders of arcane power, mages command devastating spells.',
            'prime_stat': 'int',
            'hit_dice': 4,
            'mana_dice': 12,
            'move_dice': 4,
            'thac0_progression': 'slow',
            'save_progression': 'mage',
            'skills': ['scribe'],
            'spells': ['magic_missile', 'burning_hands', 'chill_touch', 'fireball', 'lightning_bolt',
                      'sleep', 'color_spray', 'teleport', 'fly', 'invisibility', 'detect_magic',
                      'identify', 'enchant_weapon', 'meteor_swarm', 'chain_lightning',
                      # Defensive spells
                      'armor', 'shield', 'stoneskin', 'mirror_image', 'displacement', 'mana_shield',
                      'ice_armor', 'fire_shield', 'spell_reflection', 'blink',
                      'protection_from_evil', 'protection_from_good'],
        },
        'cleric': {
            'name': 'Cleric',
            'description': 'Divine servants who heal allies and smite the undead.',
            'prime_stat': 'wis',
            'hit_dice': 8,
            'mana_dice': 8,
            'move_dice': 4,
            'thac0_progression': 'medium',
            'save_progression': 'cleric',
            'skills': ['turn_undead', 'holy_smite'],
            'spells': ['cure_light', 'cure_serious', 'cure_critical', 'heal', 'group_heal',
                      'bless', 'armor', 'sanctuary', 'remove_curse', 'remove_poison',
                      'create_food', 'create_water', 'summon', 'word_of_recall', 'resurrect',
                      'harm', 'dispel_evil', 'earthquake', 'flamestrike',
                      # Defensive spells
                      'shield_of_faith', 'divine_shield', 'barkskin', 'righteous_fury',
                      'divine_protection', 'aegis', 'holy_aura', 'protection_from_evil'],
            # Clerics build Divine Favor through healing/turning undead, spend on holy_smite
        },
        'thief': {
            'name': 'Thief',
            'description': 'Cunning rogues who strike from the shadows.',
            'prime_stat': 'dex',
            'hit_dice': 6,
            'mana_dice': 2,
            'move_dice': 8,
            'thac0_progression': 'medium',
            'save_progression': 'thief',
            'skills': ['backstab', 'sneak', 'hide', 'steal', 'pick_lock', 'detect_traps',
                      'second_attack', 'trip', 'circle', 'dodge', 'evasion', 'tumble'],
            'spells': [],
            # Thieves use combo points: backstab/attacks build points, finishers spend them
            # Finishers: eviscerate (1+), kidney_shot (4+), slice_dice (3+)
        },
        'ranger': {
            'name': 'Ranger',
            'description': 'Wilderness warriors who blend combat prowess with nature magic.',
            'prime_stat': 'dex',
            'hit_dice': 10,
            'mana_dice': 4,
            'move_dice': 8,
            'thac0_progression': 'fast',
            'save_progression': 'warrior',
            'skills': ['track', 'sneak', 'hide', 'second_attack', 'dual_wield', 'camouflage',
                      'ambush', 'dodge', 'tame', 'scan'],
            'spells': ['cure_light', 'detect_magic', 'faerie_fire', 'call_lightning',
                      'barkskin', 'entangle'],
            # Rangers can tame animal companions: wolf, bear, hawk, cat, boar
        },
        'paladin': {
            'name': 'Paladin',
            'description': 'Holy warriors who combine martial skill with divine power.',
            'prime_stat': 'str',
            'hit_dice': 10,
            'mana_dice': 4,
            'move_dice': 4,
            'thac0_progression': 'fast',
            'save_progression': 'warrior',
            'skills': ['rescue', 'bash', 'turn_undead', 'second_attack', 'smite'],
            'spells': ['cure_light', 'cure_serious', 'bless', 'detect_evil', 'protection_from_evil',
                      'shield_of_faith', 'divine_shield'],
            # Paladins use auras (devotion, protection, retribution) and lay_hands ability
        },
        'necromancer': {
            'name': 'Necromancer',
            'description': 'Dark mages who command the forces of death and undeath.',
            'prime_stat': 'int',
            'hit_dice': 4,
            'mana_dice': 10,
            'move_dice': 4,
            'thac0_progression': 'slow',
            'save_progression': 'mage',
            'skills': [],
            'spells': ['chill_touch', 'animate_dead', 'vampiric_touch', 'enervation',
                      'death_grip', 'finger_of_death', 'energy_drain',
                      'poison', 'weaken', 'blindness', 'fear', 'armor', 'shield',
                      'protection_from_good'],
        },
        'bard': {
            'name': 'Bard',
            'description': 'Charismatic performers who inspire allies with magical songs.',
            'prime_stat': 'cha',
            'hit_dice': 6,
            'mana_dice': 6,
            'move_dice': 6,
            'thac0_progression': 'medium',
            'save_progression': 'thief',
            'skills': ['sneak', 'pick_lock', 'lore', 'countersong', 'fascinate', 'mockery'],
            'spells': ['charm_person', 'sleep', 'invisibility', 'haste', 'slow',
                      'cure_light', 'detect_magic', 'heroism', 'fear', 'mass_charm',
                      'bless', 'armor'],
            # Bards also learn songs automatically based on level (see BARD_SONGS in spells.py)
        },
        'assassin': {
            'name': 'Assassin',
            'description': 'Deadly killers who specialize in eliminating targets with lethal precision.',
            'prime_stat': 'dex',
            'hit_dice': 8,
            'mana_dice': 2,
            'move_dice': 10,
            'thac0_progression': 'fast',
            'save_progression': 'thief',
            'skills': ['backstab', 'sneak', 'hide', 'envenom', 'assassinate',
                      'second_attack', 'dual_wield', 'garrote', 'shadow_step', 'mark_target',
                      'dodge', 'evasion', 'feint', 'blur'],
            'spells': [],
        },
    }
    
    # Equipment slots
    WEAR_SLOTS = [
        'light',      # Light source
        'finger1',    # First ring
        'finger2',    # Second ring  
        'neck1',      # First neck slot
        'neck2',      # Second neck slot
        'body',       # Body armor
        'head',       # Helmet
        'legs',       # Leg armor
        'feet',       # Boots
        'hands',      # Gloves
        'arms',       # Arm guards
        'shield',     # Shield
        'about',      # Cloak/cape
        'waist',      # Belt
        'wrist1',     # First wrist
        'wrist2',     # Second wrist
        'wield',      # Main weapon
        'hold',       # Held item
        'dual_wield', # Off-hand weapon
    ]
    
    # Item types
    ITEM_TYPES = [
        'light', 'scroll', 'wand', 'staff', 'weapon', 'treasure', 'armor',
        'potion', 'worn', 'other', 'trash', 'container', 'note', 'drink',
        'key', 'food', 'money', 'boat', 'fountain', 'portal'
    ]
    
    # Weapon types
    WEAPON_TYPES = [
        'hit', 'sting', 'whip', 'slash', 'bite', 'bludgeon', 'crush',
        'pound', 'claw', 'maul', 'thrash', 'pierce', 'blast', 'punch',
        'stab', 'slice', 'cleave', 'smash'
    ]
    
    # Sector types (terrain)
    SECTOR_TYPES = {
        'inside': {'move_cost': 1, 'description': 'Indoors'},
        'city': {'move_cost': 1, 'description': 'City streets'},
        'field': {'move_cost': 1, 'description': 'Open field'},
        'forest': {'move_cost': 2, 'description': 'Dense forest'},
        'hills': {'move_cost': 2, 'description': 'Rolling hills'},
        'mountain': {'move_cost': 3, 'description': 'Steep mountains'},
        'water_swim': {'move_cost': 2, 'description': 'Shallow water'},
        'water_noswim': {'move_cost': 50, 'description': 'Deep water'},
        'underwater': {'move_cost': 3, 'description': 'Underwater'},
        'flying': {'move_cost': 1, 'description': 'Flying'},
        'desert': {'move_cost': 2, 'description': 'Arid desert'},
        'swamp': {'move_cost': 3, 'description': 'Murky swamp'},
        'dungeon': {'move_cost': 1, 'description': 'Dungeon corridor'},
    }

    # Terrain movement cost modifiers (scaffolding for future terrain-based rules)
    TERRAIN_MOVE_COST_MODIFIERS = {
        sector: 1.0 for sector in SECTOR_TYPES
    }
    
    # Position states
    POSITIONS = ['dead', 'mortally_wounded', 'incapacitated', 'stunned',
                 'sleeping', 'resting', 'sitting', 'fighting', 'standing']
    
    # Directions
    DIRECTIONS = {
        'north': {'opposite': 'south', 'abbrev': 'n'},
        'east': {'opposite': 'west', 'abbrev': 'e'},
        'south': {'opposite': 'north', 'abbrev': 's'},
        'west': {'opposite': 'east', 'abbrev': 'w'},
        'up': {'opposite': 'down', 'abbrev': 'u'},
        'down': {'opposite': 'up', 'abbrev': 'd'},
    }

    # Poison Types for Envenom
    POISON_TYPES = {
        'venom': {
            'name': 'Deadly Venom',
            'description': 'A vial of deadly poison that causes damage over time',
            'effect': 'poison',
            'damage': 3,
            'duration': 8,
            'color': 'green',
            'hit_message': 'Your poisoned blade delivers venom!',
            'victim_message': 'You feel poison coursing through your veins!',
            'room_message': '{attacker} strikes {victim} with a poisoned blade!'
        },
        'neurotoxin': {
            'name': 'Blinding Neurotoxin',
            'description': 'A paralytic toxin that blinds the target',
            'effect': 'blind',
            'duration': 6,
            'color': 'yellow',
            'hit_message': 'Your neurotoxin strikes true!',
            'victim_message': 'You are blinded by the neurotoxin!',
            'room_message': '{attacker} blinds {victim} with a toxic strike!'
        },
        'viper_venom': {
            'name': 'Viper Venom',
            'description': 'Potent snake venom causing severe agony',
            'effect': 'extra_damage',
            'damage': 15,
            'color': 'red',
            'hit_message': 'Your viper venom burns through their flesh!',
            'victim_message': 'Excruciating pain shoots through your body!',
            'room_message': '{attacker}\'s viper venom causes {victim} to writhe in agony!'
        },
        'silencer': {
            'name': 'Silencing Toxin',
            'description': 'A magical poison that seals the vocal cords',
            'effect': 'silence',
            'duration': 5,
            'color': 'magenta',
            'hit_message': 'Your silencing toxin takes effect!',
            'victim_message': 'Your throat constricts! You cannot speak!',
            'room_message': '{attacker} strikes {victim} with a silencing toxin!'
        },
        'torpor': {
            'name': 'Torpor Poison',
            'description': 'A sedative poison that slows reactions',
            'effect': 'slow',
            'duration': 7,
            'penalty': -2,
            'color': 'blue',
            'hit_message': 'Your torpor poison slows their movements!',
            'victim_message': 'Your limbs feel sluggish and heavy!',
            'room_message': '{attacker}\'s poison slows {victim}\'s movements!'
        },
        'nightshade': {
            'name': 'Essence of Nightshade',
            'description': 'A dark essence that weakens the body',
            'effect': 'weaken',
            'duration': 6,
            'penalty': -3,
            'stat': 'str',
            'color': 'black',
            'hit_message': 'Nightshade essence saps their strength!',
            'victim_message': 'Your muscles feel weak and useless!',
            'room_message': '{attacker}\'s nightshade weakens {victim}!'
        },
        'hemotoxin': {
            'name': 'Crimson Hemotoxin',
            'description': 'A blood poison that causes severe internal bleeding',
            'effect': 'poison',
            'damage': 5,
            'duration': 6,
            'color': 'bright_red',
            'hit_message': 'Your hemotoxin causes internal bleeding!',
            'victim_message': 'You taste blood as the hemotoxin attacks your veins!',
            'room_message': '{attacker}\'s hemotoxin causes {victim} to bleed profusely!'
        }
    }

    # Ensure directories exist
    @classmethod
    def ensure_directories(cls):
        """Create required directories if they don't exist."""
        for directory in [cls.PLAYER_DIR, cls.LOG_DIR]:
            os.makedirs(directory, exist_ok=True)

# Create directories on import
Config.ensure_directories()
